//map() does not execute the function for empty elements.
//map() does not change the original array.
let studentRecords = ['Mrugendra','Martin','Vraj','Bhautik','Uddhav'] 

//The map() method creates a new array with the results of calling a function for every array element.
let namesMap = studentRecords.map(myFunction);
//The map() method calls the provided function once for each element in an array, in order.
console.log(namesMap); 


function myFunction(num) {
    return num.toUpperCase();
  }


// =================================================================================================================================//
//FITLER
//The filter() method creates an array filled with all array elements that pass a test (provided by a function).
//filter() does not change the original array.
let studentMarks = [55,66,77,88,33,11,22,45];

let marksFilter = studentMarks.filter(myFilterFunc);
console.log(marksFilter);

function myFilterFunc(marks){
    return marks>=55;
}

// =================================================================================================================================//
//REDUCE
//The reduce() method executes a reducer function for each value of an array.
//reduce() returns a single value which is the function's accumulated result.
let ex = [12,33,44,5,67,8];

// let add = ex.reduce(myReduceFunction,0);
// let add = ex.reduce((sum,num)=>{
//     return sum+num;
// },0);
let add = ex.reduce((sum,num)=> sum+num);
console.log(add);

// function myReduceFunction(total,num){
//     return total+num;
// }
