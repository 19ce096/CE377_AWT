const userLeft = false
const userwatchingCatMeme = false

function watchTutorialPromise(){
    return new Promise((resolve,reject)=>{
        if(userLeft){
            reject({
                name:'User Left',
                message: ':('
            });
        }else if(userwatchingCatMeme){
            reject({
                name:'User Watching Cat Meme',
                message:'Vinit Rathod'
            });
        }else{
            resolve("Have a great Day");
        }
    });
}

watchTutorialPromise().then((message)=>{
    console.log("Your Message : "+message);
}).catch((err)=>{
    console.log(err.name+ " "+err.message);
});



let p = new Promise((resolve,reject)=>{
    let a = 3;
    if (a === 2){
        resolve("Successfull");
    }else{
        reject("Failed");
    }
});

p.then((message)=>{
    console.log("We are in then keyword : "+message);
    // watchTutorialPromise()
}).catch((err)=>{
    console.log("We are in catch keyword : "+err);
})


console.log("Between function and variable p");