// Example of synchronous callback
function display(name){
    console.log("Inside Callback Funtion")
    console.log(name);
}

function myName(name,myCallback){
  console.log("Inside myName")
  myCallback(name);
}

// display("VINIT");
myName("VINIT",display);

setInterval(myFunction, 1000);


function myFunction() {
  let d = new Date();
  console.log(
    d.getHours() + ":" +
    d.getMinutes() + ":" +
    d.getSeconds()
  );
}