// [a, b, ...rest] = [10, 20, 30, 40, 50];
// console.log(a); // 10
// console.log(b); // 20
// console.log(rest); // [30, 40, 50]

// TASK1: Object Destructuring with “Rest” Syntax
const obj = {
    a: 1,
    b: 2,
    c: 3,
    d: 4,
    e: 5
  };
  const a={
    c,
    e,
    ...restOfObj
  } = obj;
  console.log(c); // 3
  console.log(e); // 5
  console.log(restOfObj); // not defined
  console.log(a);

const arr = [45,22,44,789,2123,54];

const [q,r,...restofArray] = [45,22,44,789,2123,54];
console.log(q,r);
console.log(restofArray);

// const a = "Variable name 'a' is taken";
// const obj1 = {
//   a: 1,
//   b: 2,
//   c: 3,
// };
// const {
//   a: userName
// } = obj1;
// console.log(a); // "Variable name 'a' is taken"
// console.log(userName); // 1