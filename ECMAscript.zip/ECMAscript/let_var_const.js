//Understanding let,var and const keyword

console.log("LET keyword");
let x = 3;

console.log(x);


//In let keyword this will give Reference Error as we cannot give value to a variable before declaring
//using let keyword
// a = 5;
// let a;
// console.log(a);

let b = 6;
{
    // let keyword is having block scope
    //in this block b will be 7
    let b = 7;
    console.log(b);
}
//and here b will be 6
console.log(b);

//we cannot redeclared a variable using let keyword
//SyntaxError: Identifier 'x' has already been declared
// let x = 6;
// console.log(x);


// -----------------------------------------------------------------------------------------------------------------------------------//
console.log("VAR keyword");
var a = 7;
console.log(a);


//we can initailize a variable before its dealaration, it is done with the help of hoisting concept
c = 8;
var c;
console.log(c);

//we can also redeclare the variable with the help of var keyword
var a = 9;
console.log(a);

//var keyword is having function scope


// -----------------------------------------------------------------------------------------------------------------------------------//

console.log("CONST keyword");
const d = 5;
console.log(d);

//it cannot be reinitailized
//it cannot be redeclared
//use while making an array,object,function,regexp
//we cannnot reassign a const value,const array and const object
//but we can change a const array and const object

const cars = ['bmw','tesla','maruti','suzuki'];
cars[0] = 'Toyota'; // we can change element
cars.push("Audi"); // we can add element
console.log(cars);

// but we cannot reassign a Array
// SyntaxError: Identifier 'cars' has already been declared
// const cars = [];


// we can change the property of the objects but we can't reassign the objects variable
const objects = {type:'Fiat',model:'500',color:'white'};

objects.color = 'red';

objects.person = 'VINIT';

console.log(objects);